-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2019 at 04:12 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e-cmate`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gravel`
--

CREATE TABLE `tbl_gravel` (
  `sno` int(11) NOT NULL,
  `user id` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `sitename` varchar(100) NOT NULL,
  `phonenumber` bigint(250) NOT NULL,
  `loadrequired` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_list`
--

CREATE TABLE `tbl_list` (
  `sno` int(11) NOT NULL,
  `msand_loadavailable` int(3) NOT NULL,
  `psand_loadavailable` int(3) NOT NULL,
  `gravel_loadavailable` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_list`
--

INSERT INTO `tbl_list` (`sno`, `msand_loadavailable`, `psand_loadavailable`, `gravel_loadavailable`) VALUES
(1, 30, 20, 40);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_msand`
--

CREATE TABLE `tbl_msand` (
  `sno` int(11) NOT NULL,
  `user id` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `sitename` varchar(100) NOT NULL,
  `phonenumber` bigint(250) NOT NULL,
  `loadrequired` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_psand`
--

CREATE TABLE `tbl_psand` (
  `sno` int(11) NOT NULL,
  `user id` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `sitename` varchar(100) NOT NULL,
  `phonenumber` bigint(250) NOT NULL,
  `loadrequired` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `user_id` varchar(60) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(20) NOT NULL,
  `name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `email`, `password`, `name`) VALUES
('482', '', 'admin', 'admin'),
('sakthi', 'ssakthipratheesh@gmail.com', 'sakthi', 'Sakthi Pratheesh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_gravel`
--
ALTER TABLE `tbl_gravel`
  ADD UNIQUE KEY `sno` (`sno`);

--
-- Indexes for table `tbl_list`
--
ALTER TABLE `tbl_list`
  ADD UNIQUE KEY `sno` (`sno`);

--
-- Indexes for table `tbl_msand`
--
ALTER TABLE `tbl_msand`
  ADD UNIQUE KEY `sno` (`sno`);

--
-- Indexes for table `tbl_psand`
--
ALTER TABLE `tbl_psand`
  ADD UNIQUE KEY `sno` (`sno`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `unique` (`password`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_gravel`
--
ALTER TABLE `tbl_gravel`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_list`
--
ALTER TABLE `tbl_list`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_msand`
--
ALTER TABLE `tbl_msand`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_psand`
--
ALTER TABLE `tbl_psand`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
