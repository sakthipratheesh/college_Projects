<?php
include('includes/headeradmin.php');
$updateId=$_GET['id'];
if(@$_POST['submit']){
	echo"works<br>";
	$name = @$_POST['inp_name'];
	$email = @$_POST['inp_email'];
	$password = @$_POST['inp_password'];
	
	/*echo"FORM datas:<br>";
	echo"NAME:".$name." <br>";
	echo"EMAIL:".$email ."<br>";
	echo"PASSWORD:".$password;*/
	
	$sql="UPDATE `tbl_users`
	SET `name`='$name',
	`email`='$email',
	`password`='$password'
	WHERE user_id='$updateId'";
	
	$result=$conn->query($sql);
	
	if($result){
		echo "update success!";
		header('location:users.php');
	}
	else{
		echo "update failed!";
	}
}

	$selectsql="SELECT * FROM tbl_users where user_id='$updateId'";
	$userdata=$conn->query($selectsql);
	$row =$userdata->fetch_assoc();
?>
 <!DOCTYPE html>
<html>
<head>
	<title> USERS UPDATE </title>
	<link href="style2.css" rel="stylesheet">
</head>
<div class ="content">
	<marquee><h4><i><u>UPDATE CONTENTS</u></i></h4></marquee>


	<FORM action="#" method="POST" class="formstyle">
		<TABLE class="database-confirm" >
			<TR>
				<td>NAME</TD>
				<TD><input type="TEXT" name="inp_name" required value="<?= $row['name'];?>"></TD>
			</TR>
			<TR>
				<TD>EMAIL</TD>
				<TD><input type="EMAIL" name="inp_email" required value="<?=$row['email'];?>"></TD>
			</TR>
			<TR>
				<TD>PASSWORD</TD>
				<TD><input type="PASSWORD"  name="inp_password" required value="<?=$row['password'];?>"></TD>
			</TR>
			<TR>
				<TD></TD>
				<TD><input type="submit" name="submit" value="UPDATE"></TD>
			</TR>	
		</TABLE>
	</FORM>
</DIV>
<?php
include('includes/FOOTER.php');
?>
