<?= include('includes/headeradmin.php'); 
include('includes/config.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title> STOCK AVAILABLE </title>
	<link href="style2.css" rel="stylesheet">
</head>
<body>
	<div class="content">
	<h2>The available stocks are</h2>
		<table class="database">
			
		
			
		<?php
			
				$sql="SELECT * FROM `tbl_list";
				$userlist=$conn->query($sql);
				/* if ($userlist)
					echo "query executed successfully";
				else
					echo "query: '".$sql."' failed"; */
			
				$i=1;
				while($row=$userlist->fetch_assoc()){ 
					?>
				<tr>
					<th>MSAND LOAD AVAILABLE</th>
				
				</tr>
					<tr>
						<td><?php echo $row['msand_loadavailable']; ?></td>
						
					</tr>
						
					<tr>
						<th>PSAND LOAD AVAILABLE</th>
					
					</tr>

					<tr>
						<td><?php echo $row['psand_loadavailable']; ?></td>
						
					</tr>
					<tr>
						<th>GRAVEL LOAD AVAILABLE</th>
						
					</tr>
		
					<tr>
						<td><?php echo $row['gravel_loadavailable']; ?></td>
					</tr>
					<TR>
						<TH> <center>UPDATE</center></TH>
					</TR>
					<TR>
						<TD>
							<center><a href="update.php?id=<?php echo $row['gravel_loadavailable'];?>">CLICK HERE</a></center>
						</TD>
					</TR>	
					<?php
				}
			?>
		</table>
	</div>
</body>	
<?= include('includes/FOOTER.php');?>

					