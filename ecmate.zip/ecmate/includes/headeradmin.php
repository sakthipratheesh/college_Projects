
<?php
session_start();
include('includes/config.php');
//if(!isset($_SESSION['login_name']))
//	header('location:login.php')
?>
<html>
<head>
	<link href="style2.css" rel="stylesheet">
</head>
<body>
	<header>
		<a href="admin.php">HOME</a>
		<a href="orderdetails.php">ORDER DETAILS</a>
		<a href="users.php">USERS</a>
		<a href="stock.php">STOCK</a>
		<a href="logout.PHP">LOGOUT</a>
	</header>
</body>
</html>	