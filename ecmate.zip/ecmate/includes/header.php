
<?php
include('includes/config.php');
session_start();
if(!isset($_SESSION['login_name']))
	header('location:login.php')
?>
<!DOCTYPE html>
<html>
<head>
	<link href="style2.css" rel="stylesheet">
</head>
<body>
	<header>
		<a href="index.php">HOME</a>
		<a href="material.php">MATERIAL</a>
		<a href="logout.PHP">LOGOUT</a>
	</header>
</body>
</html>	