<!DOCTYPE html>
<html>
<head></head>
<body >
	</footer>
		<h4 style="font-family: 'Work Sans', sans-serif;position: relative;top: 350px; left: 860px;font-size: 22.5px;color: #3B236E ">COPYRIGHTS &copy; 2019 : SAKTHI INDUSTRIES</h4>
	</footer>
</body>
</html>