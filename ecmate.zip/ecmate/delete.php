
<?php 
	include('includes/config.php');
	$deleteId= $_GET['id'];
	$sql="DELETE FROM `tbl_users` WHERE `user_id`='$deleteId'";
	$conn->query($sql);
	header('location:users.php');
?>
<?php include('includes/footer.php');?>