<?php	include('includes/headeradmin.php')?>
<!DOCTYPE html>
<html>
<head>
	<title> USERS  </title>
	<link href="style2.css" rel="stylesheet">
</head>
<body>
	<div class="content">
	<h2>The available users  are</h2>
	<table class="database">
		<tr>
			<th>sno</th>
			<th>User_id</th>
			<th>Name</th>
			<th>Email</th>
			<th>Action</th>
		</tr>
		<?php
		
			$sql="SELECT * FROM `tbl_users`";
			$userlist=$conn->query($sql);
			/* if ($userlist)
				echo "query executed successfully";
			else
				echo "query: '".$sql."' failed"; */
		
			$i=1;
			while($row=$userlist->fetch_assoc()){ 
				?>
				<tr>
					<td><?php echo $i++ ?></td>
					<td><?php echo $row['user_id']; ?></td>
					<td><?php echo $row['name']; ?></td>
					<td><?php echo $row['email']; ?></td>
					<td>
						<a href="edit.php?id=<?php echo $row['user_id'];?>">Edit</a> <hr>
						<a href="delete.php?id=<?php echo $row['user_id'];?>">Delete</a>
					</td>
				
				</tr>
				<?php
			}
		?>
	</table>
</div>
<?php include('includes/footer.php');?>