<?php include('includes/headeradmin.php');?>
<?php
//$updateid=$_GET['sno'];
if(@$_POST['submit']){
	echo"works<br>";
	$msand = @$_POST['inp_msand_loadavailable'];
	$psand = @$_POST['inp_psand_loadavailable'];
	$gravel = @$_POST['inp_gravel_loadavailable'];

	$sql="PDUATE `tbl_list` SET  
	`msand_loadavailable`='$msand',
	`psand_loadavailable`='$psand',
	`gravel_loadavailable`='$gravel'" ;
	
	$result=mysqli_connect('localhost','root','','e-cmate')->query($sql);
	
	if($result){
		echo "update success!";
		header('location:stock.php');
	}
	else{
		echo "update failed!";
	}
}	

$sql = "SELECT * FROM `tbl_list`";
$userlist= mysqli_connect('localhost','root','','e-cmate')->query($sql);
$row=$userlist->fetch_assoc();
?>
<html>
<head>
	<title> UPDATE STOCK </title>
	<link href="style2.css" rel="stylesheet">
</head>
<body>
	<div class ="content">
		<h2>UPDATE CONTENTS</h2>
		<FORM action="#" method="POST" class="formstyle">
			<TABLE class="database" >
				<TR>
					<td>MSAND LOAD</TD>
					<TD><input class="update-input" type="integer" name="inp_msand_loadavailable" required value="<?= $row['msand_loadavailable'];?>"></TD>
				</TR>
				<TR>
					<TD>PSAND LOAD</TD>
					<TD><input type="integer" class="update-input" name="inp_psand_loadavailable" required value="<?=$row['psand_loadavailable'];?>"></TD>
				</TR>
				<TR>
					<TD>GRAVEL</TD>
					<TD><input type="integer" class="update-input" name="inp_gravel_loadavailable" required value="<?=$row['gravel_loadavailable'];?>"></TD>
				</TR>
				<TR>
					<TD></TD>
					<TD><input type="submit" name="submit" class="update-btn" value="UPDATE"></TD>
				</TR>	
			</TABLE>
		</FORM>
	</div>
</body>
</html>	
 <?php include('includes/FOOTER.php');?>
			