<?php	include('includes/header.php')?>
<!DOCTYPE HTML>
<html>
<body>
<head>
	<title> MATERIAL CHOOSING</title>
	<link href="style2.css" rel="stylesheet">
</head>
	</body>
		<div class="content">
			<h1>WELCOME TO SAKTHI INDUSTRIES</h1>
		</div>
		<div class="content1">
			<div class="material-flex">
					<div class="flex-box">
						<div class="imagebox">
							<img src="assets\msand.jpg" width="380px" height="150px">
						</div>
						<center><h2>MSAND</h2></center>
						<?= "Manufactured sand / M Sand is an fine aggregate, which is an Eco friendly and economical alternative to river sand. It is manufactured by crushing hard granite stone and are finely graded to match the IS standard requirements."?>
						<center><H4>To Order This Material</h4></center><center><A href="msandform.php">CLICK HERE</A></center>
					</div>
					<div class="flex-box">
						<div class="imagebox">
							<img src="assets\psand.jpg" width="380px" height="150px">
						</div>
						<center><H2>PSAND</H2></center>
						<?= "Plastering M Sand (PSand) is used for Wall plastering and brick work purposes. The granule thickness is 150 microns to 2.38 mm is ideal for block masonry.Plastering M Sand to be mixed in the cement ratio 14:16"?>
						<center><H4>To Order This Material</h4></center><center><A href="psandform.php">CLICK HERE</A></center>
					</div>
					<div class="flex-box">
						<div class="imagebox">
							<img src="assets\garvel.jpg" width="380px" height="150px">
						</div>
						<center><H2>GRAVEL</H2></center>
						<?= " commercial gravel permeability, porosity and pore size distribution,key properties for effective bridging and production capacity are grain size distribution, shape, and turbidity.
						,Crushed stone may be made from granite, limestone, dolostone,etc"?>
						<center><H4>To Order This Material</h4></center> <center><A href="gravelform.php">CLICK HERE</A></center>
					</div>
			</div>			
		</div>
	</body>
</html>	

<?= include('includes/footer.php');?>

