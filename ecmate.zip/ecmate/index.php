<?php include('includes/header.php'); 
include('includes/config.php');

?>
<!DOCTYPE html>
<html>
<head>
	<title> INDEX </title>
	<link href="style2.css" rel="stylesheet">
	
</head>
<body >
	<div class="box1" >
		<div class ="content-top">
			<h1 class="index-hi">HI !
			<?php echo $_SESSION['login_name'];?></h1>
		</div>
		<div class ="content-index">
			<h1>WELCOME TO SAKTHI INDUSTRIES</h1>		
		</div>
		<div class ="index-about">
			<h1>To know about our products and our achievements click below</h1>
			<a href="aboutus.php">CONTINUE >></a>
		</div>
	</div>	
<body>
<?= include('includes/FOOTER.php');?>