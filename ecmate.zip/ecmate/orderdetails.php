<?php include('includes/config.php');
include('includes/headeradmin.php'); ?>
<!DOCTYPE html>
<html>
    <head>
        <title>ORDER DETAILS</title>
    </head>
<body>
	<h1 class="od-title"><center>THE LIST OF ORDERS </center></h1>
	<div class="od-flex">
		<div class="od-flex-box">
		<h2>Msand Load Details</h2>
			<table class="database">
					<tr>
						<th>User_id</th>
						
						<th colspan="2">Name</th>
						<th>Site name</th>
						<TH>Loadrequired</TH>
						<th>Phonenumber</th>
						<th>DELIVERY CHARGE</th>
					    <th>TOTAL COST </th>
					</tr>
					<?php
						$sql = 'SELECT * FROM `tbl_msand`';
						$result = $conn-> query($sql);
						while($row = $result-> fetch_assoc()){
						?>
							<tr>
								<td><?= $row['user id']; ?></td>
								<td colspan="2"><?= $row['name']; ?></td>
								<td><?= $row['sitename']; ?></td>
								<td><?= $row['loadrequired']; ?></td>
								<td><?= $row['phonenumber']; ?></td>
							 <td><?= $row['loadrequired']*3000;?></td>	
								<td><?= $row['loadrequired']*3000+0.05*3000 ;?></td>
							</tr>
							<?php
							}
						?>
				</table>
			
		</div>
		<div class="od-flex-box">
		<h2>Psand Load Details</h2>
			<table class="database">
					<tr>
						<th>User_id</th>
						<th colspan="2">Name</th>
						<th>Site name</th>
						<TH>Loadrequired</TH>
						<th>Phonenumber</th>
						<th>DELIVERY CHARGE</th>
						<th>TOTAL COST </th>
					</tr>
					<?php
						$sql = 'SELECT * FROM `tbl_psand`';
						$result = $conn-> query($sql);
						while($row = $result-> fetch_assoc()){
						?>
							<tr>
								<td><?= $row['user id']; ?></td>
								<td colspan="2"><?= $row['name']; ?></td>
								<td><?= $row['sitename']; ?></td>
								<td><?= $row['loadrequired']; ?></td>
								<td><?= $row['phonenumber']; ?></td>
							    <td><?= $row['loadrequired']*4000;?></td>	
							    <td><?= $row['loadrequired']*4000+0.05*4000 ;?></td>
							</tr>
							<?php
							}
						?>
				</table>
			
	</div>
	<div class="od-flex-box">
	<h2>Gravel Load Details</h2>
		<table class="database">
				<tr>
					<th>User_id</th>
					<th colspan="2">Name</th>
					<th>Site name</th>
					<TH>Loadrequired</TH>
					<th>Phonenumber</th>
					<th>DELIVERY CHARGE</th>
					<th>TOTAL COST </th>
				</tr>
				<?php
					$sql = 'SELECT * FROM `tbl_gravel`';
					$result = $conn-> query($sql);
					while($row = $result-> fetch_assoc()){
					?>
						<tr>
							<td><?= $row['user id']; ?></td>
							<td colspan="2"><?= $row['name']; ?></td>
							<td><?= $row['sitename']; ?></td>
							<td><?= $row['loadrequired']; ?></td>
							<td><?= $row['phonenumber']; ?></td>
							<td><?= $row['loadrequired']*2000;?></td>	
							<td><?= $row['loadrequired']*2000+0.05*2000 ;?></td>
						</tr>
						<?php
						}
					?>
			</table>
		</div>
	</div>	
</body>
</html>	
<?php include('includes/footer.php');?>
