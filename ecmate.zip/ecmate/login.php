<?php
	session_start();
	include('includes/config.php');
	if(@$_POST['submit']){
		
		$user_id = @$_POST['inp_user_id'];
		$password = @$_POST['inp_password'];

		if($user_id == 'admin'&& $password=='admin' || $password == "ADMIN"){
			$loginsql= "SELECT * FROM `tbl_users` WHERE user_id='$user_id' and password='$password'";
			$logincheck = $conn->query($loginsql);
			//$result = $logincheck->fetch_assoc();

			if($logincheck){
				header('location: admin.php');
			}
		}
		else{
			$loginsql="SELECT * FROM `tbl_users` WHERE user_id='$user_id' and password='$password'";

			$logincheck = $conn->query($loginsql);
			$result = $logincheck->fetch_assoc();
			
			if($result){
				$_SESSION['login_user_id']=$result['user_id'];
				$_SESSION['login_password']=$result['password'];
				$_SESSION['login_name']=$result['name'];
				echo "LOGIN success!";
				header('location:index.php');
			}
			else{
				echo "LOGIN failed!";
			}
		}
		
/*		$loginsql="SELECT * FROM `tbl_users` WHERE user_id='$user_id' and password='$password'";

		$logincheck = $conn->query($loginsql);
		$result = $logincheck->fetch_assoc();
		
		if($result){
			$_SESSION['login_user_id']=$result['user_id'];
			$_SESSION['login_password']=$result['password'];
			$_SESSION['login_name']=$result['name'];
			echo "LOGIN success!";
			header('location:index.php');
		}
		else{
			echo "LOGIN failed!";
		} */
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title>LOGIN PAGE</title>
	<link href="style2.css" rel="stylesheet">
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>
<body>
	<div class="content">
		<h1>WELCOME TO SAKTHI INDUSTRIES</h1>
	</div>	
	<div class="box">
		<div class="login-content">
			<h1>LOGIN CONTENT</h1>
			<form action="#" method="POST" class="formstyle">
				<i class="fa fa-user" aria-hidden="true"></i>
				<input type="text" name="inp_user_id" placeholder="Username" required></br>
				<i class="fa fa-lock" aria-hidden="true"></i>
				<input type="PASSWORD"  name="inp_password" placeholder="PASSWORD" required></br>
				<button class="btn" type="submit" name="submit" value="LOGIN">LOGIN</button>
			</form>
		</div>
	</div>	
	<div class="signup">
	<h1> REGISTER IN OUR INDUSTRIES CLICK HERE </h1>
		<a href="signin.php" >SIGN IN</a>
	</div>
</body>
</html>