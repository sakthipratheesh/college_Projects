<?php include('includes/headeradmin.php'); 
include('includes/config.php');

?>
<!DOCTYPE html>
<html>
<head>
	<title> INDEX </title>
	<link href="style2.css" rel="stylesheet">
	
</head>
<body >
	<div class="box1">
		<div class ="content-top">
			<h1 class="index-hi">HI ADMINISTRATOR</h1>
		</div>
	<div class ="content-index">
			<h1>WELCOME TO SAKTHI INDUSTRIES</h1>		
	</div>
<body>
</html>	
	
<?= include('includes/FOOTER.php');?>