<?php
include('includes/config.php');
if(@$_POST['submit']){
	echo"works<br>";
	$name = @$_POST['inp_name'];
	$user_id = @$_POST['inp_user_id'];
	$email = @$_POST['inp_email'];
	$password = @$_POST['inp_password'];
	/*echo"form datas:<br>";
	echo"user_id:".$user_id." <br>";
	echo"name:".$name ."<br>";
	echo"PASSWORD:".$password;*/
	$sql="INSERT INTO `tbl_users`( `user_id`, `email`, `password`,`name`) VALUES ('$user_id','$email','$password','$name')";
	$result=$conn->query($sql);
	if($result){
		echo"registration success";
		header('location:login.php');
	}
	else{
		echo"registration failed";
	}
}

?>
<!DOCTYPE html>
<html>
<head>
	<title> SIGN IN </title>
	<link href="style2.css" rel="stylesheet">
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>
<body>
	<div class="content">
		<h1>WELCOME TO SAKTHI INDUSTRIES</h1>
	</div>	
	<div class="box-signup">
		<div class ="login-content">
			<h2>REGISTER CONTENT</h2>
			<form action="#" method="POST" class="formstyle">
				<i class="fa fa-user-circle" aria-hidden="true"></i>
				<input type="text" name="inp_user_id"  placeholder="User Name" required></br>
				<i class="fa fa-lock" aria-hidden="true"></i>
				<input type="PASSWORD"  name="inp_password" placeholder="Password" required></br>
				<i class="fa fa-envelope-open" aria-hidden="true"></i>
				<input type="EMAIL" name="inp_email" placeholder="Your Email" required></br>
				<i class="fa fa-user" aria-hidden="true"></i>
				<input type="TEXT" name="inp_name" placeholder="Your Name" required></br>
				<button class="btn" type="submit" name="submit" value="SAVE">REGISTER</button>
			</form>
		</div>
	</div>
	<div class="signup">
	<h1>ALREADY HAVE AN ACCOUNT CLICK HERE </h1>
		<a href="login.php" >LOGIN</a>
	</div>
</body>
<?php include('includes/FOOTER.php'); ?>
