
<?php
include('includes/config.php');

if(@$_POST['submit']){
	echo"works<br>";
	
	$user_id = @$_POST['inp_user_id'];
	$name = @$_POST['inp_name'];
	$sitename = @$_POST['inp_sitename'];
	$phonenumber = @$_POST['inp_phonenumber'];
	$loadrequired = @$_POST['inp_loadrequired'];
	$sql="INSERT INTO `tbl_msand`(`user id`,`name`, `sitename`, `phonenumber`,`loadrequired`) VALUES ('$user_id','$name','$sitename','$phonenumber','$loadrequired')";
	$result=$conn->query($sql);
	if($result){
		echo"registration success";
		 header('location: orderconfirmmsand.php');
	}
	else{
		echo"registration failed";
	}
}
?>

<head>
	<title> ORDERING FORM OF MSAND</title>
	<link href="style2.css" rel="stylesheet">
</head>
<body>
	<div class ="CONTENT">
		<h2>ORDER CONTENTS</h2>
	</div>
	<form action="#" method="POST" class="formstyle">
		<table class="database-confirm" >
			<TR>
				<td>USER_ID</TD>
				<TD><input type="text" class="confirm-input" name="inp_user_id" required></TD>
			</TR>
			<TR>
				<td>NAME</TD>
				<TD><input type="TEXT" class="confirm-input" name="inp_name" required></TD>
			</TR>
			<TR>
				<td>SITENAME</TD>
				<TD><input type="TEXT" class="confirm-input" name="inp_sitename" required></TD>
			</TR>
			<TR>
				<TD>PHONENUMBER</TD>
				<TD><input type="phonenumber" class="confirm-input" name="inp_phonenumber" required></TD>
			</TR>
			
			<TR>
				<TD>LOADAVAILABLE</TD>
				<TD>
				<?php
				$sql = "SELECT * FROM `tbl_list`";
				$userlist= mysqli_connect('localhost','root','','e-cmate')->query($sql);
				$row=$userlist->fetch_assoc();?>
				 <h3><?php echo $row['msand_loadavailable'];?> </h3>
				</TD>
			</TR>
			<TR>
				<TD>LOADREQUIRED</TD>
				<TD><input type="number" class="confirm-input" name="inp_loadrequired" required></TD>
			</TR>
			<TR>
				<TD></TD>
				<TD><input type="submit" class="msand-confirm-btn" name="submit" value="SAVE"></TD>
			</TR>	
		</table>
	</form>
	
</body>

 <?php include('includes/FOOTER.php');?>