<?php	include('includes/header.php')?>
<head>
	<title> MSAND ORDER DETAILS</title>
	<link href="style2.css" rel="stylesheet">
</head>
<body>
	<div class ="content">
		<h2>MSAND ORDER CONTENTS</h2>
	</div>
	<div class="flex-box-confirm">
		<div class="imagebox-confirm">
			<img src="assets\msand.jpg" width="380px" height="150px">
		</div>	
	</div>
	<form action="#" method="POST" class="formstyle">
		<table class="database-order-confirm" >
			
			<?php
				//include('includes/config.php');
				 $sql = 'SELECT * FROM `tbl_msand`order by `sno`desc limit 1 ';
				$result = $conn-> query($sql);
				$row = $result-> fetch_assoc()
			?>
			<TR>
				<td>USER ID:</td><td> <?= $row['user id']; ?></td>
			</TR>
			<TR>
				<td>NAME: </td><td><?= $row['name']; ?></td>
			</TR>
			<TR>
				<td>SITENAME:</td><td> <?= $row['sitename']; ?></td>
			</TR>
			<TR>
				<td>LOAD REQUIRED: </td><td><?= $row['loadrequired']; ?></td>
			</TR>
			<TR>
				<td>PHONE NUMBER :</td><td><?= $row['phonenumber']; ?></td>
			</TR>
			</TR>
			<TR>
				<td>DELIVERY CHARGE(3000/LOAD):</td><td><?= $row['loadrequired']*3000;?></td>
			</TR>
			<TR>
				<td>TOTAL COST (INCLUDING SGST AND CGST) =</td><td><?= $row['loadrequired']*3000+0.05*3000 ;?></td>
			</TR>		
		 </table>
	</form>
</body>
  
 <?php include('includes/FOOTER.php');?>