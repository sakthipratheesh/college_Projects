# 2048
Recreated popular "2048" game using tkinter GUI in Python 3

Keeps track of current score and high score. Each new tile is highlighted with a pink font. 
Arrow keys are used to play the game. 

<img src="1.png" width="400"/>
<img src="2.png" width="400"/>